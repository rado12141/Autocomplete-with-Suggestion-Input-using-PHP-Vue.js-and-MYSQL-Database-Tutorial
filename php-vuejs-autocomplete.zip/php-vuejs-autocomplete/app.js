
const { createApp } = Vue

/**
 * Create Vue App to the selected Element
 */
var app = createApp({
    /**
     * App Data
     */
    data() {
        return {
            languages: [],
            search:'',
            suggestions:false
        }

    },
    /**
     * App Methods
     */
    methods:{
        searchLanguages(){
            /**
             * Query Suggestions
             */
            if(this.search == ""){
                this.languages = []
                this.suggestions = false
            }else{
                var formData = new FormData();
                formData.append('search', this.search)
                fetch('getLanguages.php',{
                    method:'POST',
                    body: formData
                })
                .then(response => {
                    return response.json()
                })
                .then(data => {
                    this.languages = Object.values(data)
                    this.suggestions = true
                } )
            }

        },
        getLanguage(language){
            /**
             * Write selected suggestion to the search input
             */
            this.search = language
            this.languages = []
            this.suggestions = false
        }
    }
}).mount('#SampleApp')