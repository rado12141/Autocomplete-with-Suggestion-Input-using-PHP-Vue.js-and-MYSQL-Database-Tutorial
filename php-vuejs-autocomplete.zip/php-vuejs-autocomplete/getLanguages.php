<?php 
require_once('db-connect.php');
/**
 * Search Language where name is like the search term
 */
$swhere = "";

if(isset($_POST['search']) && !empty($_POST['search'])){
    $swhere = " WHERE `name` LIKE '%{$_POST['search']}%' ";
}
$sql = "SELECT * FROM `languages` {$swhere} order by `name` asc";
$query = $conn->query($sql);
$languages = [] ;
if($query->num_rows > 0){
    $languages = array_column($query->fetch_all(MYSQLI_ASSOC), 'name');
}

echo json_encode($languages);
$conn->close();